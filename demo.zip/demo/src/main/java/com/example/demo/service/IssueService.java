package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Book;
import com.example.demo.model.Employee;
import com.example.demo.model.Issue;
import com.example.demo.model.Transaction;
import com.example.demo.repository.BookRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.IssueRepository;
import com.example.demo.service.TransactionService;

import java.time.LocalDate;

@Service
public class IssueService {

    @Autowired
    private IssueRepository issueRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private TransactionService transactionService;

    // Issue a book and create a transaction
    public Issue issueBook(Long bookId, Long employeeId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found"));

        if (!book.isAvailable()) {
            throw new RuntimeException("Book is not available");
        }

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        // Create Issue record
        Issue issue = new Issue();
        issue.setBook(book);
        issue.setEmployee(employee);
        issue.setIssueDate(LocalDate.now());
        issue.setDueDate(LocalDate.now().plusWeeks(2)); // Default due date set to 2 weeks from issue date
        issueRepository.save(issue);

        // Update Book availability
        book.setAvailable(false);
        bookRepository.save(book);

        // Create and save Transaction
        Transaction transaction = new Transaction();
        transaction.setBook(book);
        transaction.setEmployee(employee);
        transaction.setIssueDate(issue.getIssueDate());
        transaction.setDueDate(issue.getDueDate());
        transactionService.createTransaction(transaction);

        return issue;
    }

    // Return a book and update the transaction record
    public Issue returnBook(Long issueId) {
        Issue issue = issueRepository.findById(issueId)
                .orElseThrow(() -> new RuntimeException("Issue record not found"));

        // Set return date for Issue
        issue.setReturnDate(LocalDate.now());
        
        // Make the book available again
        issue.getBook().setAvailable(true);
        bookRepository.save(issue.getBook());

        // Save the Issue update
        issueRepository.save(issue);

        // Update Transaction record with return date
        Transaction transaction = transactionService.getTransactionById(issueId);
        transaction.setReturnDate(issue.getReturnDate());
        transactionService.updateTransaction(transaction);

        return issue;
    }
}