import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Employee } from './employee';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseURL = "http://localhost:8080/api/v1/employees";

  constructor(private httpClient: HttpClient) { }

  // Fetch the list of employees
  getEmployeeList(): Observable<Employee[]> {
    console.log('Fetching employee list from API...');
    return this.httpClient.get<Employee[]>(`${this.baseURL}`).pipe(
      tap(data => console.log('Response received:', data)),  // Log the response
      catchError(this.handleError)  // Centralized error handler
    );
  }

  // Create a new employee
  createEmployee(employee: Employee): Observable<Object> {
    console.log('Creating new employee:', employee);
    return this.httpClient.post(`${this.baseURL}`, employee).pipe(
      tap(data => console.log('Employee created:', data)),
      catchError(this.handleError)
    );
  }

  // Fetch employee by ID
  getEmployeeById(id: number): Observable<Employee> {
    console.log(`Fetching employee with ID: ${id}`);
    return this.httpClient.get<Employee>(`${this.baseURL}/${id}`).pipe(
      tap(data => console.log('Employee fetched:', data)),
      catchError(this.handleError)
    );
  }

  // Update an employee
  updateEmployee(id: number, employee: Employee): Observable<Object> {
    console.log(`Updating employee with ID: ${id}`);
    return this.httpClient.put(`${this.baseURL}/${id}`, employee).pipe(
      tap(data => console.log('Employee updated:', data)),
      catchError(this.handleError)
    );
  }

  // Delete an employee (optional if needed later)
  deleteEmployee(id: number): Observable<Object> {
    console.log(`Deleting employee with ID: ${id}`);
    return this.httpClient.delete(`${this.baseURL}/${id}`).pipe(
      tap(data => console.log('Employee deleted:', data)),
      catchError(this.handleError)
    );
  }

  // Centralized error handling method
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // Client-side or network error
      console.error('An error occurred:', error.error.message);
    } else {
      // Backend returned an unsuccessful response code
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}
