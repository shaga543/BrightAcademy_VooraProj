import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { BookListComponent } from './book-list/book-list.component';
import { BookFormComponent } from './book-form/book-form.component';
import { IssueBookComponent } from './issue-book/issue-book.component';
import { ReturnBookComponent } from './return-book/return-book.component';
import { TransactionListComponent } from './transaction-list/transaction-list.component';
import { PaymentModalComponent } from './payment-modal/payment-modal.component'; // Import Payment Modal


export const routes: Routes = [
    { path: 'login', component: LoginComponent },

    // Landing route (main page) after login
    { path: 'employees', component: EmployeeListComponent },
    { path: 'create-employee', component: CreateEmployeeComponent },
    { path: 'update-employee/:id', component: UpdateEmployeeComponent },
    { path: 'employee-details/:id', component: EmployeeDetailsComponent },
    { path: 'books', component: BookListComponent },
    { path: 'books/new', component: BookFormComponent },
    { path: 'books/:id/edit', component: BookFormComponent },
    { path: 'issue-book', component: IssueBookComponent },
    { path: 'return-book', component: ReturnBookComponent },
    { path: 'transactions', component: TransactionListComponent },
    { path: 'payment-modal', component: PaymentModalComponent },

    // Default route to login initially
    { path: '', redirectTo: '/login', pathMatch: 'full' },
];