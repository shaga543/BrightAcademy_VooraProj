// transaction.model.ts
export interface Transaction {
    id: number;
    book: {
      id: number;
      title: string;
    };
    employee: {
      id: number;
      firstName: string;
      lastName: string;
    };
    issueDate: string;
    dueDate: string;
    returnDate: string;
  }