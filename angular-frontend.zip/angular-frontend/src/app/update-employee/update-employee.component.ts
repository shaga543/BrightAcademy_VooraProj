import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'; // Import ActivatedRoute to get the route params
import { EmployeeService } from '../employee.service'; // Import EmployeeService
import { Employee } from '../employee'; // Import Employee model
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update-employee',
  standalone: true,
  imports:[FormsModule],
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {
  id!: number; // To store the employee ID from the route
  employee: Employee = new Employee(); // Initialize an employee object

  constructor(
    private employeeService: EmployeeService,
    private route: ActivatedRoute, // To capture the employee ID from the URL
    private router: Router
  ) {}

  ngOnInit(): void {
    // Get the 'id' from the route parameters
    this.id = this.route.snapshot.params['id'];

    // Fetch the employee data from the service using the employee ID
    this.employeeService.getEmployeeById(this.id).subscribe({
      next: (data) => {
        this.employee = data; // Set the fetched employee data
      },
      error: (err) => {
        console.error(err);
      }
    });
  }

  // Method called on form submission
  onSubmit(): void {
    // Call the updateEmployee method of the EmployeeService
    this.employeeService.updateEmployee(this.id, this.employee).subscribe({
      next: (data) => {
        // Navigate back to the employee list page on successful update
        this.router.navigate(['/employees']);
      },
      error: (err) => {
        console.error('Error updating employee', err); // Log any errors
      }
    });
  }
}
