import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Book } from './book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private baseURL = "http://localhost:8080/api/books";

  constructor(private httpClient: HttpClient) { }

  // Fetch the list of books
  getBookList(): Observable<Book[]> {
    console.log('Fetching book list from API...');
    return this.httpClient.get<Book[]>(`${this.baseURL}`).pipe(
      tap(data => console.log('Response received:', data)),
      catchError(this.handleError)
    );
  }

  // Create a new book
  createBook(book: Book): Observable<Object> {
    console.log('Creating new book:', book);
    return this.httpClient.post(`${this.baseURL}`, book).pipe(
      tap(data => console.log('Book created:', data)),
      catchError(this.handleError)
    );
  }

  // Fetch book by ID
  getBookById(id: number): Observable<Book> {
    console.log(`Fetching book with ID: ${id}`);
    return this.httpClient.get<Book>(`${this.baseURL}/${id}`).pipe(
      tap(data => console.log('Book fetched:', data)),
      catchError(this.handleError)
    );
  }

  // Update a book
  updateBook(id: number, book: Book): Observable<Object> {
    console.log(`Updating book with ID: ${id}`);
    return this.httpClient.put(`${this.baseURL}/${id}`, book).pipe(
      tap(data => console.log('Book updated:', data)),
      catchError(this.handleError)
    );
  }

  // Delete a book
  deleteBook(id: number): Observable<Object> {
    console.log(`Deleting book with ID: ${id}`);
    return this.httpClient.delete(`${this.baseURL}/${id}`).pipe(
      tap(data => console.log('Book deleted:', data)),
      catchError(this.handleError)
    );
  }

  // Update book availability
  updateBookAvailability(id: number, available: boolean): Observable<Object> {
    console.log(`Updating availability for book with ID: ${id}`);
    return this.httpClient.put(`${this.baseURL}/${id}/availability`, null, {
      params: { available: available.toString() }
    }).pipe(
      tap(data => console.log('Book availability updated:', data)),
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    return throwError(() => new Error('Something went wrong; please try again later.'));
  }
}