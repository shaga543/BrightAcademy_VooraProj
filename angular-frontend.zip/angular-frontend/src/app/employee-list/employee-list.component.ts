import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router'; // Import Router
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [
    CommonModule, // Include CommonModule here
    FormsModule
  ],
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'] // Corrected to styleUrls
})
export class EmployeeListComponent implements OnInit {
  employees: Employee[] = []; // Initialize employees as an empty array

  constructor(private employeeService: EmployeeService, private router: Router) {} 

  ngOnInit(): void {
    this.getEmployees(); // Call the method inside ngOnInit
  }

  private getEmployees() {
    this.employeeService.getEmployeeList().subscribe({
      next: (data) => {
        this.employees = data; // Set employees to the fetched data
      },
      error: (err) => {
        console.error('Error fetching employees', err); // Log error
      }
    });
  }

  employeeDetails(id: number){
    this.router.navigate(['employee-details', id]); // Corrected navigation
  }

  updateEmployee(id: number) {
    this.router.navigate(['update-employee', id]); // Corrected navigation
  }

  deleteEmployee(id: number) {
    this.employeeService.deleteEmployee(id).subscribe( data => {
      console.log(data);
      this.getEmployees();
    })
  }
}
