import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../book.service';
import { Book } from '../book.model';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-book-form',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './book-form.component.html',
  styleUrl: './book-form.component.css'
})
export class BookFormComponent implements OnInit {
  book: Book = {
    id: 0,
    title: '',
    author: '',
    genre: '',
    isbn: '',
    available: true
  };
  isEditMode = false;

  constructor(
    private bookService: BookService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id) {
      this.isEditMode = true;
      this.bookService.getBookById(id).subscribe({
        next: (data) => {
          this.book = data;
        },
        error: (err) => console.error('Error fetching book:', err)
      });
    }
  }

  saveBook(): void {
    if (this.isEditMode) {
      this.bookService.updateBook(this.book.id, this.book).subscribe({
        next: () => {
          console.log('Book updated successfully');
          this.router.navigate(['/books']);
        },
        error: (err) => console.error('Error updating book:', err)
      });
    } else {
      this.bookService.createBook(this.book).subscribe({
        next: () => {
          console.log('Book created successfully');
          this.router.navigate(['/books']);
        },
        error: (err) => console.error('Error creating book:', err)
      });
    }
  }
}