import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  private baseURL = "http://localhost:8080/api/issues";

  constructor(private http: HttpClient) { }

  issueBook(bookId: number, employeeId: number): Observable<any> {
    return this.http.post(`${this.baseURL}/issue`, null, {
      params: { bookId: bookId.toString(), employeeId: employeeId.toString() }
    });
  }

  returnBook(issueId: number): Observable<any> {
    return this.http.put(`${this.baseURL}/return/${issueId}`, null);
  }

  // Optional: Add a method to get all issued books for a specific employee
  getIssuedBooks(employeeId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseURL}?employeeId=${employeeId}`);
  }

  // Optional: Add a method to get an issue by ID
  getIssueById(issueId: number): Observable<any> {
    return this.http.get<any>(`${this.baseURL}/${issueId}`);
  }
}