import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterModule,
    EmployeeListComponent,
    CreateEmployeeComponent,
    UpdateEmployeeComponent,
    FormsModule,
    CommonModule,
    LoginComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] // Fixed typo here
})
export class AppComponent {
  title = 'Bright Academy';
  isLoggedIn = false;

  constructor(private router: Router) {} // Inject Router service here

  // Method to simulate login, which can be expanded for real authentication
  login() {
    this.isLoggedIn = true;
  }

  // Getter to determine if the current page is the login page
  get isLoginPage(): boolean {
    return this.router.url === '/login';
  }
}
