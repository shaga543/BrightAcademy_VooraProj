import { Component } from '@angular/core';
import { IssueService } from '../issue-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-return-book',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './return-book.component.html',
  styleUrl: './return-book.component.css'
})
export class ReturnBookComponent {
  issueId: number;
  message: string | null = null;  // To display success messages
  error: string | null = null;     // To display error messages

  constructor(private issueService: IssueService,private router: Router) {}

  returnBook(): void {
    this.issueService.returnBook(this.issueId).subscribe({
      next: (response) => {
        this.message = 'Book returned successfully!';
        this.error = null; // Clear any previous errors
        console.log('Book returned successfully', response);
      },
      error: (error) => {
        this.error = 'Error returning book: ' + error.error.message; // Display error message from server
        this.message = null; // Clear any previous messages
        console.error('Error returning book:', error);
      }
    });
  }
}