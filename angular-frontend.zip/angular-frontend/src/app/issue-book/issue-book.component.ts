import { Component } from '@angular/core';
import { IssueService } from '../issue-service.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-issue-book',
  templateUrl: './issue-book.component.html',
  standalone: true,
  imports: [CommonModule, FormsModule],
  styleUrls: ['./issue-book.component.css']
})
export class IssueBookComponent {
  bookId: number;
  userId: number;
  message: string | null = null;  // To display success or error messages
  error: string | null = null;     // To display error messages

  constructor(private issueService: IssueService, private router: Router) {}

  issueBook(): void {
    this.issueService.issueBook(this.bookId, this.userId).subscribe({
      next: (response) => {
        this.message = 'Book issued successfully!';
        this.error = null; // Clear any previous errors
        console.log('Book issued successfully', response);
      },
      error: (error) => {
        this.error = 'Error issuing book: ' + error.error.message; // Display error message from server
        this.message = null; // Clear any previous messages
        console.error('Error issuing book:', error);
      }
    });
  }

  // Open payment modal after issuing book
  openPaymentModal(): void {
    this.router.navigate(['/payment-modal']); // Navigate to the payment modal route
  }
}
